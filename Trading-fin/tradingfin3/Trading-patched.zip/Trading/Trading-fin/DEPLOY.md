# 🚀 Инструкция по деплою на VPS (Ubuntu/Debian)

## 1. Подготовка сервера
Подключитесь к VPS по SSH и обновите систему:
```bash
sudo apt update && sudo apt upgrade -y
```

Установите Docker и Docker Compose:
```bash
# Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Docker Compose (если не установился плагин)
sudo apt install docker-compose-plugin
```

## 2. Установка бота
1. Создайте папку для бота:
```bash
mkdir trading-bot && cd trading-bot
```

2. Загрузите файлы проекта (можно через SCP/SFTP или Git clone):
   - `Dockerfile`
   - `docker-compose.yml`
   - весь исходный код (`*.py`, `web_ui/`, `requirements.txt`)

3. (Опционально) Создайте файл `.env` для ключей, чтобы не хранить их в конфиге.

## 3. Запуск
Соберите и запустите контейнер в фоновом режиме:
```bash
sudo docker compose up -d --build
```

Проверьте статус:
```bash
sudo docker compose ps
```

## 4. Доступ к Dashboard
Откройте в браузере IP вашего сервера:
`http://YOUR_VPS_IP:8080`

Если порт закрыт фаерволом:
```bash
sudo ufw allow 8080
```

## 5. Обновление
Чтобы обновить бота (после загрузки новых файлов):
```bash
sudo docker compose down
sudo docker compose up -d --build
```
