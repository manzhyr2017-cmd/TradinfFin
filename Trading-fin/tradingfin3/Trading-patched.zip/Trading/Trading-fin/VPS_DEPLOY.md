# 🚀 Инструкция по переезду на VPS (Ubuntu)

## 1. Подготовка (Локально)
1. Убедитесь, что все изменения отправлены на GitHub:
   ```bash
   git add .
   git commit -m "Ready for deploy: NVIDIA Llama 3 + Gemini 2.5"
   git push origin main
   ```

## 2. Настройка Сервера (VPS)
Зайди на сервер через терминал (PuTTY или `ssh root@IP`).

1. **Скачай код:**
   *(Замени URL на твой репозиторий)*
   ```bash
   git clone https://github.com/TVOY-LOGIN/Trading-fin.git
   cd Trading-fin
   ```

2. **Запусти авто-установку:**
   ```bash
   chmod +x setup.sh
   ./setup.sh
   ```
   *(Этот скрипт сам обновит сервер, поставит Python и библиотеки)*

3. **Добавь ключи:**
   ```bash
   nano .env
   ```
   *Вставь туда содержимое твоего локального .env файла (правой кнопкой мыши).*
   *Нажми `Ctrl+O`, `Enter` (сохранить), `Ctrl+X` (выйти).*

## 3. Запуск Бота
Чтобы бот работал вечно (даже если выключишь комп), используем `screen`:

1. Создай сессию:
   ```bash
   screen -S tradebot
   ```

2. Запусти бота:
   ```bash
   source venv/bin/activate
   python web_ui/server.py
   ```

3. **Как выйти, не выключая бота:**
   Нажми `Ctrl+A`, затем `D`. (Detach). Бот останется работать в фоне.

4. **Как вернуться к боту:**
   ```bash
   screen -r tradebot
   ```
